package com.app.bank;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AplicacionBancariaApplicationTests {

	@Test
	void contextLoads() {
	}

}
