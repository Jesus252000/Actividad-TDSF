package com.app.bank.models.dto;


public class ErrorDTO {
    private String message;
    private int status;
}
