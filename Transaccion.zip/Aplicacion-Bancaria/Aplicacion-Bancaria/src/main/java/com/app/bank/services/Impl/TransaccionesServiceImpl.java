package com.app.bank.services.Impl;

import org.springframework.stereotype.Service;

import com.app.bank.models.dto.TransaccionDTO;
import com.app.bank.services.TransaccionesService;

@Service
public class TransaccionesServiceImpl implements TransaccionesService{

    @Override
    public void realizarTransaccion(TransaccionDTO transaccion) {
        // TODO Auto-generated method stub
        throw new UnsupportedOperationException("Unimplemented method 'realizarTransaccion'");
    }

}
