package com.app.bank.models.entities;

public enum Permission {

    CONSULTAR_SALDO,
    TRANSFERIR,
    CONSULTAR_TODAS_CUENTAS,
    REALIZAR_DEPOSITO,
    REALIZAR_RETIRO
}
