INSERT INTO usuarios (username, password, role) VALUES ("user1", "$2a$12$RDz5T3rjANLolX0nQ9yzi./9J5uHkbq70dF0XkVZW/h27ySiWtkrC", "ADMIN");

INSERT INTO usuarios (username, password, role) VALUES  ("user2", "$2a$12$bwOgjSxJmIW.XneeCqg33OS1PpiqIcdYAPJa9UTr7ALIa87iJQARe", "USER");


INSERT INTO cuentas (numero_cuenta, saldo, usuario_id) VALUES (2376347, 2500.75, 1);

INSERT INTO cuentas (numero_cuenta, saldo, usuario_id) VALUES (658513, 1500.50, 2);






